package com.cathaybk.javaedu.lesson2.practice.practice1;

/**
 * abstract class Airplane
 * @author 00587053
 *
 */
public abstract class Airplane implements Flyer {

}
