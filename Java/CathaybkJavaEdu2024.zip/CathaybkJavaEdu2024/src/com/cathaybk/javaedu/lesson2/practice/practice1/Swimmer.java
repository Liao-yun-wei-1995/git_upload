package com.cathaybk.javaedu.lesson2.practice.practice1;

public interface Swimmer {
    void swim();
}
