package com.cathaybk.javaedu.lesson2;

public class AbstractDemo {

    public static void main(String[] args) {
//        Yellow yellow = new Yellow();

        Taxi taxi = new Taxi();
        taxi.showColor();
        taxi.changeColor("藍色");
    }

}
