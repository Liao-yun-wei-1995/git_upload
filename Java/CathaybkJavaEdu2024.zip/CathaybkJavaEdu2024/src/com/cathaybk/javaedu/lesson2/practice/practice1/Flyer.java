package com.cathaybk.javaedu.lesson2.practice.practice1;

/**
 * interface Flyer
 * @author 00587053
 *
 */
public interface Flyer {

    /**
     * 
     */
    void fly();

}
