package com.cathaybk.javaedu.lesson2.oop;

public abstract class Bird implements Wings {

}