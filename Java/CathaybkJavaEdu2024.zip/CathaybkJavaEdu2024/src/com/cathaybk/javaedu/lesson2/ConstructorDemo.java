package com.cathaybk.javaedu.lesson2;

/**
 * <pre>
 * 建構子（Constructor）
 * 建構子與繼承
 * </pre>
 */
public class ConstructorDemo {

    public static void main(String[] args) {
        // DEMO 1 2
        Father father = new Father();

        // DEMO 3
        //        Son son = new Son();

        // DEMO 4
        //        Son sonPeter = new Son("Peter");
        //        System.out.println(sonPeter.getName());
    }

}
