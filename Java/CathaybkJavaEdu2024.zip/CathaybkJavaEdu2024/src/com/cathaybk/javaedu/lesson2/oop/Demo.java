package com.cathaybk.javaedu.lesson2.oop;

public class Demo {

    public static void main(String[] args) {
        Flyer phoenix = new Phoenix();
        Flyer tweety = new Tweety();
        phoenix.fly();
        tweety.fly();
    }

}
