package com.cathaybk.javaedu.lesson2;

public interface USB {

    String TYPE = "Type-C";

    void connect();
}
