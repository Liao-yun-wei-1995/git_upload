package com.cathaybk.javaedu.lesson2.oop;

public class Tweety extends Bird {

    @Override
    public void patWings() {
        System.out.println("崔弟拍打翅膀");
    }

    @Override
    public void fly() {
        System.out.println("崔弟飛");
    }

}
