package com.cathaybk.javaedu.lesson2;

public class Magician extends Role {

    @Override
    public void fight() {
        System.out.println("魔法攻擊");
    }

}
