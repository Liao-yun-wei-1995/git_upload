package com.cathaybk.javaedu.lesson2.oop.practice;

/**
 * <pre>
 * 小試身手
 * </pre>
 */
public class Father {

    public Father() {
        System.out.println("Hey");
    }

    public Father(String msg) {
        System.out.println("Hey, " + msg);
    }

}