package com.cathaybk.javaedu.lesson2;

public class RPGGame {

    public static void main(String[] args) {

//        new Role();
        Magician magician = new Magician();
        magician.fight();
        magician.run();
    }

}
