package com.cathaybk.javaedu.lesson2.oop.practice;

public interface Flyer {
    void fly();

}
