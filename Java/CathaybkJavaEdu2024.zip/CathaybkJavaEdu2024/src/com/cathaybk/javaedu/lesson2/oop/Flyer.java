package com.cathaybk.javaedu.lesson2.oop;

public interface Flyer {
    void fly();

}
