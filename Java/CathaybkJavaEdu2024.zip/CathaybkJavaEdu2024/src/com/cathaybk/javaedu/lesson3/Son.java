package com.cathaybk.javaedu.lesson3;

public class Son extends Father {

    public Son(String name, int age, String dept) {
        super(name, age, dept);
    }

    public void sonPrint() {
        System.out.println("Son Print");
    }

}
