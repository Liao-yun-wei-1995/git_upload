package com.cathaybk.javaedu.lesson1;

/**
 * <pre>
 * 遞增（減）運算
 * </pre>
 */
public class IncrementTest {

    public static void main(String[] args) {
        // DEMO ----------
        int a = 1;
        System.out.println(++a);
        System.out.println(a);
        System.out.println(a++);
        System.out.println(a);

        // DEMO ----------
        //        int a = 1;
        //        int b = ++a;
        //        int c = 3;
        //        c = c + (a++);
        //
        //        System.out.println(a);
        //        System.out.println(b);
        //        System.out.println(c);
    }

}