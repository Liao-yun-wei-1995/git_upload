package com.cathaybk.javaedu.lesson1;

/**
 * <pre>
 * 存取權限修飾子
 * </pre>
 */
public class Modifier {

    public String name = "Peter";

    public void doMethod() {
        System.out.println("method: " + name);
    }

}
