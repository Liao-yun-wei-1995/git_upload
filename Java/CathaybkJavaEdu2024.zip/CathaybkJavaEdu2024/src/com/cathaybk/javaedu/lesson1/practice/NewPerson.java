package com.cathaybk.javaedu.lesson1.practice;

/**
 * <pre>
 * 練習五
 * </pre>
 */
public class NewPerson {

    public static void main(String[] args) {
        Person person = new Person();
        person.setName("Wilson");
        System.out.println("Hello, " + person.getName());
    }

}
