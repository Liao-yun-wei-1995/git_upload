package com.cathaybk.javaedu.lesson1.practice;

/**
 * <pre>
 * 練習五
 * </pre>
 */
public class Person {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
