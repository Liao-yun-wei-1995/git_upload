package com.cathaybk.javaedu.lesson1;

public class ModifierDemo {

    public static void main(String[] args) {

        Modifier modifier = new Modifier();
        System.out.println(modifier.name);
        modifier.doMethod();

    }

}
