package com.cathaybk.javaedu.lesson1; // package

/**
 * <pre>
 * 定義類別
 * </pre>
 */
public class Car { // class

	private String brand; // property

	private String type; // property

	public void startEngine() { // method
		System.out.println("Hello" + brand + " " + type + "is ready.");
	}

}
