package com.cathaybk.javaedu.lesson1;

public class FinalExample {

    private static final String name = "Peter";

    public static void main(String[] args) {
//        name = "John";
        System.out.println(name);
    }

}
